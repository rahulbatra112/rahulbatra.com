"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog"
import { ChevronLeft, ChevronRight, X } from "lucide-react"
import { fetchGooglePhotos } from "@/lib/google-photos"

type Photo = {
  id: string
  title: string
  url: string
  date: string
}

export function PhotoGallery() {
  const [photos, setPhotos] = useState<Photo[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedPhoto, setSelectedPhoto] = useState<Photo | null>(null)
  const [dialogOpen, setDialogOpen] = useState(false)

  useEffect(() => {
    async function loadPhotos() {
      try {
        // In a real implementation, this would fetch from Google Photos API
        const data = await fetchGooglePhotos()
        setPhotos(data)
      } catch (error) {
        console.error("Failed to load photos:", error)
      } finally {
        setLoading(false)
      }
    }

    loadPhotos()
  }, [])

  function handlePrevious() {
    if (!selectedPhoto) return
    const currentIndex = photos.findIndex((photo) => photo.id === selectedPhoto.id)
    const prevIndex = (currentIndex - 1 + photos.length) % photos.length
    setSelectedPhoto(photos[prevIndex])
  }

  function handleNext() {
    if (!selectedPhoto) return
    const currentIndex = photos.findIndex((photo) => photo.id === selectedPhoto.id)
    const nextIndex = (currentIndex + 1) % photos.length
    setSelectedPhoto(photos[nextIndex])
  }

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Array(9)
          .fill(0)
          .map((_, i) => (
            <Card key={i} className="overflow-hidden">
              <CardContent className="p-0">
                <div className="aspect-square bg-muted animate-pulse" />
              </CardContent>
            </Card>
          ))}
      </div>
    )
  }

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {photos.map((photo) => (
          <Card key={photo.id} className="overflow-hidden">
            <CardContent className="p-0">
              <Dialog
                open={dialogOpen && selectedPhoto?.id === photo.id}
                onOpenChange={(open) => {
                  setDialogOpen(open)
                  if (!open) setSelectedPhoto(null)
                }}
              >
                <DialogTrigger asChild>
                  <Button
                    variant="ghost"
                    className="w-full h-full p-0 hover:opacity-95 transition-opacity"
                    onClick={() => setSelectedPhoto(photo)}
                  >
                    <div className="aspect-square relative w-full">
                      <Image src={photo.url || "/placeholder.svg"} alt={photo.title} fill className="object-cover" />
                    </div>
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl p-0 bg-transparent border-none">
                  <div className="relative">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute top-2 right-2 bg-background/80 z-10"
                      onClick={() => setDialogOpen(false)}
                    >
                      <X className="h-5 w-5" />
                    </Button>
                    <div className="relative aspect-[4/3] w-full">
                      <Image
                        src={selectedPhoto?.url || ""}
                        alt={selectedPhoto?.title || ""}
                        fill
                        className="object-contain"
                      />
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute left-2 top-1/2 -translate-y-1/2 bg-background/80"
                      onClick={handlePrevious}
                    >
                      <ChevronLeft className="h-6 w-6" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute right-2 top-1/2 -translate-y-1/2 bg-background/80"
                      onClick={handleNext}
                    >
                      <ChevronRight className="h-6 w-6" />
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        ))}
      </div>
    </>
  )
}

