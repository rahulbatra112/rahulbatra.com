import { Card, CardContent, CardHeader } from "@/components/ui/card"

type TimelineItem = {
  year: string
  title: string
  description: string
}

const timelineData: TimelineItem[] = [
  {
    year: "2023",
    title: "Senior Software Engineer",
    description: "Led the development of a major product feature that increased user engagement by 40%.",
  },
  {
    year: "2021",
    title: "Software Engineer",
    description: "Joined a fast-growing tech company and contributed to multiple successful product launches.",
  },
  {
    year: "2019",
    title: "Graduated with Masters",
    description: "Completed my Master's degree in Computer Science with a focus on artificial intelligence.",
  },
  {
    year: "2017",
    title: "First Tech Job",
    description: "Started my career as a junior developer at a startup, working on web applications.",
  },
  {
    year: "2015",
    title: "Bachelor's Degree",
    description: "Graduated with a Bachelor's degree in Computer Engineering.",
  },
]

export function Timeline() {
  return (
    <div className="space-y-8">
      {timelineData.map((item, index) => (
        <div key={index} className="relative pl-8 md:pl-0">
          <div className="md:grid md:grid-cols-5 md:gap-8 items-start">
            <div className="md:col-span-1 flex items-center mb-4 md:mb-0 md:justify-end">
              <div className="font-bold text-xl md:text-2xl text-primary">{item.year}</div>
            </div>

            <div className="md:col-span-4">
              <Card>
                <CardHeader className="pb-2">
                  <h3 className="font-semibold text-lg">{item.title}</h3>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{item.description}</p>
                </CardContent>
              </Card>
            </div>

            {/* Timeline connector */}
            <div className="absolute left-0 top-6 h-full md:left-1/2 md:transform md:-translate-x-1/2 md:top-10">
              <div className="w-3 h-3 rounded-full bg-primary"></div>
              {index < timelineData.length - 1 && <div className="w-0.5 h-full bg-border ml-1"></div>}
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

