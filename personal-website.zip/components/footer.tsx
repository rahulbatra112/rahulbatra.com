import Link from "next/link"
import { SocialLinks } from "@/components/social-links"

export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="border-t bg-background">
      <div className="container px-4 py-8 mx-auto">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-4">
            <h3 className="text-lg font-bold">Rahul Batra</h3>
            <p className="text-sm text-muted-foreground">
              Sharing my journey, achievements, and passions with the world.
            </p>
          </div>

          <div className="space-y-4">
            <h3 className="text-sm font-semibold">Pages</h3>
            <nav className="flex flex-col space-y-2">
              <Link href="/" className="text-sm text-muted-foreground hover:text-primary">
                Home
              </Link>
              <Link href="/gallery" className="text-sm text-muted-foreground hover:text-primary">
                Gallery
              </Link>
              <Link href="/contact" className="text-sm text-muted-foreground hover:text-primary">
                Contact
              </Link>
              <Link href="/booking" className="text-sm text-muted-foreground hover:text-primary">
                Book a Meeting
              </Link>
            </nav>
          </div>

          <div className="space-y-4">
            <h3 className="text-sm font-semibold">Contact</h3>
            <p className="text-sm text-muted-foreground">hello@rahulbatra.com</p>
            <p className="text-sm text-muted-foreground">New Delhi, India</p>
          </div>

          <div className="space-y-4">
            <h3 className="text-sm font-semibold">Connect</h3>
            <SocialLinks />
          </div>
        </div>

        <div className="flex flex-col md:flex-row justify-between items-center mt-8 pt-8 border-t">
          <p className="text-sm text-muted-foreground">© {currentYear} Rahul Batra. All rights reserved.</p>
          <div className="flex gap-4 mt-4 md:mt-0">
            <Link href="/privacy" className="text-xs text-muted-foreground hover:text-primary">
              Privacy Policy
            </Link>
            <Link href="/terms" className="text-xs text-muted-foreground hover:text-primary">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}

