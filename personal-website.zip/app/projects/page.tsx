import { ProjectCard } from "@/components/project-card"
import { projectsData } from "@/lib/projects-data"

export const metadata = {
  title: "Projects | Rahul Batra",
  description: "Explore the projects I've worked on throughout my career",
}

export default function ProjectsPage() {
  return (
    <div className="container px-4 py-12 mx-auto">
      <div className="max-w-3xl mx-auto text-center space-y-4 mb-12">
        <h1 className="text-4xl font-bold">My Projects</h1>
        <p className="text-lg text-muted-foreground">
          A collection of projects I've worked on, from web applications to open-source contributions.
        </p>
      </div>

      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 max-w-6xl mx-auto">
        {projectsData.map((project) => (
          <ProjectCard
            key={project.slug}
            title={project.title}
            description={project.description}
            tags={project.tags}
            image={project.image}
            githubUrl={project.githubUrl}
            liveUrl={project.liveUrl}
            slug={project.slug}
          />
        ))}
      </div>
    </div>
  )
}

