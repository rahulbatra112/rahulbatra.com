import { BookingForm } from "@/components/booking-form"
import { CalendarDays, Clock, MapPin } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export const metadata = {
  title: "Book a Meeting | Rahul Batra",
  description: "Schedule a meeting with me",
}

export default function BookingPage() {
  return (
    <div className="container px-4 py-12 mx-auto">
      <div className="max-w-3xl mx-auto space-y-12">
        <div className="text-center space-y-4">
          <h1 className="text-4xl font-bold">Book a Meeting</h1>
          <p className="text-lg text-muted-foreground">
            Schedule a time to chat, collaborate, or discuss opportunities.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <CalendarDays className="w-5 h-5 mt-1 text-primary" />
                    <div>
                      <h3 className="font-medium">Available Days</h3>
                      <p className="text-sm text-muted-foreground">Monday to Friday</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <Clock className="w-5 h-5 mt-1 text-primary" />
                    <div>
                      <h3 className="font-medium">Meeting Duration</h3>
                      <p className="text-sm text-muted-foreground">30 minutes or 1 hour</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <MapPin className="w-5 h-5 mt-1 text-primary" />
                    <div>
                      <h3 className="font-medium">Meeting Type</h3>
                      <p className="text-sm text-muted-foreground">Virtual (Zoom, Google Meet, etc.)</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="p-4 bg-muted rounded-lg">
              <h3 className="font-medium mb-2">Note</h3>
              <p className="text-sm text-muted-foreground">
                Please provide details about the purpose of our meeting when booking. I'll confirm the appointment and
                send meeting details via email.
              </p>
            </div>
          </div>

          <BookingForm />
        </div>
      </div>
    </div>
  )
}

