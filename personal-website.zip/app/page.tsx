import { Button } from "@/components/ui/button"
import { Timeline } from "@/components/timeline"
import { SocialLinks } from "@/components/social-links"
import Image from "next/image"
import Link from "next/link"
import { ProjectCard } from "@/components/project-card"

export default function Home() {
  return (
    <div className="container px-4 py-12 mx-auto">
      {/* Hero Section */}
      <section className="flex flex-col-reverse md:flex-row items-center justify-between gap-8 py-12">
        <div className="flex-1 space-y-4">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight">Hi, I'm Rahul Batra</h1>
          <p className="text-xl text-muted-foreground">
            Welcome to my personal space where I share my journey, achievements, and passions.
          </p>
          <div className="flex flex-wrap gap-4 pt-4">
            <Button asChild size="lg">
              <Link href="/contact">Get in Touch</Link>
            </Button>
            <Button variant="outline" size="lg" asChild>
              <Link href="/gallery">View Gallery</Link>
            </Button>
          </div>
        </div>
        <div className="flex-1 flex justify-center md:justify-end">
          <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden border-4 border-primary">
            <Image
              src="/placeholder.svg?height=320&width=320"
              alt="Rahul Batra"
              fill
              className="object-cover"
              priority
            />
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16" id="about">
        <div className="max-w-3xl mx-auto text-center space-y-6">
          <h2 className="text-3xl font-bold">About Me</h2>
          <p className="text-lg text-muted-foreground">
            I'm passionate about technology, innovation, and making a positive impact. Throughout my journey, I've had
            the opportunity to work on exciting projects and collaborate with amazing people. This website is a glimpse
            into my personal and professional life.
          </p>
          <p className="text-lg text-muted-foreground">
            When I'm not working, you can find me exploring new places, reading books, or experimenting with new
            technologies. I believe in continuous learning and pushing boundaries.
          </p>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-16" id="timeline">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">My Journey</h2>
          <Timeline />
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-16" id="projects">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-8">Featured Projects</h2>
          <p className="text-lg text-muted-foreground text-center max-w-3xl mx-auto mb-12">
            Here are some of the projects I've worked on. Each project represents a unique challenge and learning
            experience.
          </p>

          <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
            <ProjectCard
              title="E-Commerce Platform"
              description="A full-stack e-commerce solution with payment processing and inventory management."
              tags={["React", "Node.js", "MongoDB"]}
              image="/placeholder.svg?height=200&width=400"
              githubUrl="https://github.com/rahulbatra/ecommerce"
              liveUrl="https://ecommerce-demo.rahulbatra.com"
            />
            <ProjectCard
              title="Task Management App"
              description="A productivity application for managing tasks, projects, and team collaboration."
              tags={["Next.js", "TypeScript", "Prisma"]}
              image="/placeholder.svg?height=200&width=400"
              githubUrl="https://github.com/rahulbatra/taskmanager"
              liveUrl="https://tasks.rahulbatra.com"
            />
            <ProjectCard
              title="Portfolio Website"
              description="A personal portfolio website showcasing my work and achievements."
              tags={["Next.js", "Tailwind CSS", "Vercel"]}
              image="/placeholder.svg?height=200&width=400"
              githubUrl="https://github.com/rahulbatra/portfolio"
              liveUrl="https://rahulbatra.com"
            />
          </div>

          <div className="flex justify-center mt-12">
            <Button asChild size="lg">
              <Link href="/projects">View All Projects</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Connect Section */}
      <section className="py-16 bg-muted rounded-xl p-8" id="connect">
        <div className="max-w-3xl mx-auto text-center space-y-8">
          <h2 className="text-3xl font-bold">Let's Connect</h2>
          <p className="text-lg">
            Follow me on social media or reach out directly. I'm always open to new connections and opportunities.
          </p>
          <SocialLinks className="justify-center" />
          <div className="pt-4">
            <Button asChild size="lg">
              <Link href="/booking">Schedule a Meeting</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}

