import { Suspense } from "react"
import { PhotoGallery } from "@/components/photo-gallery"
import { Skeleton } from "@/components/ui/skeleton"

export const metadata = {
  title: "Gallery | Rahul Batra",
  description: "A collection of photos from my life and adventures",
}

export default function GalleryPage() {
  return (
    <div className="container px-4 py-12 mx-auto">
      <div className="max-w-3xl mx-auto text-center space-y-4 mb-12">
        <h1 className="text-4xl font-bold">Photo Gallery</h1>
        <p className="text-lg text-muted-foreground">
          A collection of moments from my life, adventures, and achievements.
        </p>
      </div>

      <Suspense fallback={<GallerySkeleton />}>
        <PhotoGallery />
      </Suspense>
    </div>
  )
}

function GallerySkeleton() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {Array(9)
        .fill(0)
        .map((_, i) => (
          <Skeleton key={i} className="aspect-square rounded-lg" />
        ))}
    </div>
  )
}

