export interface Project {
  title: string
  slug: string
  description: string
  content: string[]
  features?: string[]
  technologies?: string[]
  tags: string[]
  image: string
  githubUrl?: string
  liveUrl?: string
  date?: string
}

export const projectsData: Project[] = [
  {
    title: "E-Commerce Platform",
    slug: "ecommerce-platform",
    description: "A full-stack e-commerce solution with payment processing and inventory management.",
    content: [
      "This e-commerce platform was built to provide small businesses with an affordable and customizable online store solution. The project focused on creating a seamless shopping experience while giving store owners powerful tools to manage their inventory and sales.",
      "I designed and implemented both the frontend user interface and the backend systems, including product management, shopping cart functionality, secure checkout process, and order management.",
    ],
    features: [
      "User authentication and profile management",
      "Product catalog with categories and search",
      "Shopping cart and wishlist functionality",
      "Secure payment processing integration",
      "Order tracking and history",
      "Admin dashboard for inventory and order management",
    ],
    technologies: [
      "React for the frontend user interface",
      "Node.js and Express for the backend API",
      "MongoDB for database storage",
      "Redux for state management",
      "Stripe for payment processing",
      "AWS S3 for image storage",
    ],
    tags: ["React", "Node.js", "MongoDB", "Express", "Stripe"],
    image: "/placeholder.svg?height=400&width=800",
    githubUrl: "https://github.com/rahulbatra/ecommerce",
    liveUrl: "https://ecommerce-demo.rahulbatra.com",
    date: "January 2023",
  },
  {
    title: "Task Management App",
    slug: "task-management-app",
    description: "A productivity application for managing tasks, projects, and team collaboration.",
    content: [
      "The Task Management App was developed to help teams organize their work and collaborate effectively. It provides a visual interface for tracking tasks through different stages of completion.",
      "I built this application with a focus on real-time updates and collaboration features, allowing team members to see changes as they happen and work together seamlessly.",
    ],
    features: [
      "Kanban board for visual task management",
      "Task assignment and due dates",
      "Project organization and tagging",
      "Comment threads for task discussions",
      "File attachments and sharing",
      "Email notifications and reminders",
    ],
    technologies: [
      "Next.js for the frontend and API routes",
      "TypeScript for type safety",
      "Prisma for database ORM",
      "PostgreSQL for data storage",
      "Socket.io for real-time updates",
      "Vercel for deployment",
    ],
    tags: ["Next.js", "TypeScript", "Prisma", "PostgreSQL", "Socket.io"],
    image: "/placeholder.svg?height=400&width=800",
    githubUrl: "https://github.com/rahulbatra/taskmanager",
    liveUrl: "https://tasks.rahulbatra.com",
    date: "June 2022",
  },
  {
    title: "Portfolio Website",
    slug: "portfolio-website",
    description: "A personal portfolio website showcasing my work and achievements.",
    content: [
      "This portfolio website was designed to showcase my projects, skills, and professional journey. It serves as a central hub for anyone interested in learning more about my work and getting in touch.",
      "I focused on creating a clean, responsive design with smooth animations and intuitive navigation to provide visitors with an enjoyable browsing experience.",
    ],
    features: [
      "Responsive design for all device sizes",
      "Dark/light mode toggle",
      "Project showcase with detailed case studies",
      "Interactive timeline of professional experience",
      "Contact form and meeting scheduler",
      "Integration with social media profiles",
    ],
    technologies: [
      "Next.js for static site generation",
      "Tailwind CSS for styling",
      "Framer Motion for animations",
      "Vercel for hosting and deployment",
      "React Hook Form for form handling",
      "TypeScript for type safety",
    ],
    tags: ["Next.js", "Tailwind CSS", "Vercel", "TypeScript", "React"],
    image: "/placeholder.svg?height=400&width=800",
    githubUrl: "https://github.com/rahulbatra/portfolio",
    liveUrl: "https://rahulbatra.com",
    date: "March 2023",
  },
  {
    title: "Weather Dashboard",
    slug: "weather-dashboard",
    description: "A real-time weather application with forecasts and historical data visualization.",
    content: [
      "The Weather Dashboard provides users with current weather conditions and forecasts for locations around the world. It visualizes weather data in an intuitive interface with charts and maps.",
      "I built this application to practice working with third-party APIs and data visualization libraries, focusing on creating a useful tool that presents complex data in an accessible way.",
    ],
    features: [
      "Current weather conditions display",
      "5-day weather forecast",
      "Historical weather data charts",
      "Location search with autocomplete",
      "Saved locations for quick access",
      "Weather alerts and notifications",
    ],
    technologies: [
      "React for the user interface",
      "OpenWeatherMap API for weather data",
      "Chart.js for data visualization",
      "Mapbox for location mapping",
      "Local storage for saving user preferences",
      "Progressive Web App capabilities",
    ],
    tags: ["React", "APIs", "Chart.js", "Mapbox", "PWA"],
    image: "/placeholder.svg?height=400&width=800",
    githubUrl: "https://github.com/rahulbatra/weather-dashboard",
    liveUrl: "https://weather.rahulbatra.com",
    date: "August 2022",
  },
  {
    title: "Recipe Finder",
    slug: "recipe-finder",
    description: "A web application for discovering and saving recipes based on available ingredients.",
    content: [
      "Recipe Finder helps users discover meals they can cook with ingredients they already have. Users can search by ingredients, dietary restrictions, or meal types to find suitable recipes.",
      "I created this project to solve a common problem: figuring out what to cook with the ingredients you have on hand. It combines search functionality with personalization features to help users find and save recipes they love.",
    ],
    features: [
      "Ingredient-based recipe search",
      "Dietary restriction and allergy filters",
      "Recipe saving and collections",
      "Meal planning calendar",
      "Nutritional information display",
      "User ratings and reviews",
    ],
    technologies: [
      "Vue.js for the frontend framework",
      "Firebase for authentication and database",
      "Spoonacular API for recipe data",
      "Vuex for state management",
      "Progressive Web App features",
      "Responsive design for mobile use",
    ],
    tags: ["Vue.js", "Firebase", "APIs", "PWA", "Responsive"],
    image: "/placeholder.svg?height=400&width=800",
    githubUrl: "https://github.com/rahulbatra/recipe-finder",
    liveUrl: "https://recipes.rahulbatra.com",
    date: "November 2022",
  },
  {
    title: "Budget Tracker",
    slug: "budget-tracker",
    description: "A personal finance application for tracking expenses, income, and financial goals.",
    content: [
      "The Budget Tracker helps users manage their personal finances by tracking income, expenses, and savings goals. It provides visualizations of spending patterns and financial progress over time.",
      "I developed this application to practice building CRUD operations and data visualization while creating a useful tool for personal finance management.",
    ],
    features: [
      "Income and expense tracking",
      "Category-based budget allocation",
      "Financial goal setting and tracking",
      "Spending analysis and reports",
      "Recurring transaction management",
      "Data export for tax purposes",
    ],
    technologies: [
      "React for the user interface",
      "Node.js and Express for the backend",
      "MongoDB for data storage",
      "D3.js for data visualization",
      "JWT for authentication",
      "Responsive design for all devices",
    ],
    tags: ["React", "Node.js", "MongoDB", "D3.js", "Express"],
    image: "/placeholder.svg?height=400&width=800",
    githubUrl: "https://github.com/rahulbatra/budget-tracker",
    liveUrl: "https://budget.rahulbatra.com",
    date: "April 2022",
  },
]

